(function(){
	angular.module("medicine").config(function($routeProvider){
	$routeProvider
	.when("/",{
	    controller : "logincontroller",
	    templateUrl : "app/views/login.html"
	  })
	 .when("/campusmind",{
		controller:"priyacontroller1",
		templateUrl:"app/views/priyaview1.html"
	})
	.when("/ordermedicine",{
		controller:"priyacontroller2",
		templateUrl:"app/views/priyaview2.html"
	})
	.when("/checkstatus",{
		controller:"priyacontroller3",
		templateUrl:"app/views/priyaview3.html"
	})
	.when("/doctor",{
		templateUrl:"app/views/home.html"
	})
	.when("/page2",{
		controller:"page1controller",
		templateUrl:"app/views/page1.html"
	})
	.when("/orderpage",{
		controller:"nagaordercontroller",
		templateUrl:"app/views/order.html"
	})
	.when("/add",{
        controller : "tablet_add_controller",
        templateUrl:"app/views/add_template.html"
       })
       .when("/view",{
      	controller:"priyacontroller1",
      	templateUrl:"app/views/priyaview1.html"
      	})
      	.when("/ordermedicine",{
     	controller:"priyacontroller2",
  		templateUrl:"app/views/priyaview2.html"
 		})
 		.when("/checkstatus",{
  		controller:"priyacontroller3",
  		templateUrl:"app/views/priyaview3.html"
	 }) 
	 .when("/medicines",{
  		controller : "souravmvcontroller",
  		templateUrl : "app/views/medicinesview.html"
 		})
 		.when("/admin",{
		templateUrl : "app/views/home_naresh.html"
	})
	.when("/orders",{
		controller : "souravoacontroller",
		templateUrl : "app/views/orderapprove.html"
	});
	});
}());