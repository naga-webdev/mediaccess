(function(){	
	angular.module("medicine").controller("souravmvcontroller",function($scope,$http){
		
		$scope.url = "/medicines";
		$scope.medicines = null;
		$scope.user = "Saurav";
		
		$scope.sorton = "_id";
		$scope.rev = true;
		$scope.start = 0;
		$scope.total = 0;
		$scope.limit = 10;
		$scope.page = 0;
		$scope.totalpages = 0;
		
		function errorHandler(e,s,x){
			alert("something went wrong..");
		}
		$scope.refresh = function(){
			console.log("Refresing..");
			$http.get($scope.url)
			.success(function(r,s,x){
				$scope.medicines = r;
				$scope.total = $scope.medicines.length;
				$scope.setPage();
			}).error(errorHandler);
		};
		$scope.sortonfun = function(param){
			console.log("welcome to life..");
			$scope.sorton = param;
			$scope.rev = $scope.rev ? false : true;
		};
		$scope.nextPage = function(){
			$scope.start = $scope.start + $scope.limit;
			$scope.setPage();
		};
		$scope.prevPage = function(){
			$scope.start = $scope.start - $scope.limit;
			$scope.setPage();
		};
		$scope.setPage = function(){
			$scope.page = (Math.floor(($scope.start+1)/$scope.limit)) +1;
			$scope.totalpages = $scope.total/$scope.limit;
			console.log($scope.page,$scope.totalpages);
		};
		$scope.refresh();
		
	});
	angular.module("medicine").filter("floor",function(){
		return function(arg){
			return Math.floor(arg);
		};
	});
}());
