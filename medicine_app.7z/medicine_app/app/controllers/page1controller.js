(function(){
	angular.module("medicine").controller("page1controller",function($scope,$http){
		
		$scope.doctorlog = null;
		$scope.date ="";
		$scope.tabid ="";
		$scope.mid ="";
		$scope.count="";
		$scope.symp="";
		$scope.status="";
		$scope.display=false;
		$scope.message="";
			
			
			function successHandler(r,s,x){
				$scope.doctorlog = r;
				if($scope.status===null){
					notify();
				}
			};
			function errorHandler(e,s,x){
				alert("Some thing went wrong");
			};
			function notify(){
				$scope.message =" CampusMind Is Requested for New tablets ";
			}
			$scope.fetch = function(){
				$http.get("/doclog")
				.success(successHandler)
				.error(errorHandler);
			};
			$scope.updateStatus = function(uid){
				var data = {
					status : "approved"
				};
				$http.put("/approve/"+uid,data)
				.success(function(r,s,x){
					$scope.fetch();
				alert("your Request is Approved");
				}).error(function(e,s,x){
					alert("something wentwrong");
				});
			};
			$scope.reject = function(uid){
				var data = {
					status : "Rejected"
				};
				$http.put("/approve/"+uid,data)
				.success(function(r,s,x){
					$scope.fetch();
				alert("Request Rejected");
				}).error(function(e,s,x){
					alert("something wentwrong");
				});
			};
	});
}());