(function(){
angular.module("medicine")
.controller("souravoacontroller",function($scope,$http){		
		$scope.url = "/adminlog";
		$scope.orders = null;
		$scope.user = "Saurav";
		
		function errorHandler(e,s,x){
			alert("something went wrong..");
		}
		$scope.refresh = function(){
			console.log("Refresing..");
			$http.get($scope.url)
			.success(function(r,s,x){
				$scope.orders = r;
			}).error(errorHandler);
		};
		$scope.setStatus = function(id, st){
			var data = {
				status: st
			};
			console.log(data);
			
			$http.put($scope.url+"/"+id,data)
			.success(function(r,s,x){
				console.log("Status successfully Edited..");
				$scope.refresh();
			})
			.error(errorHandler);
		};
		$scope.refresh();
	});
}());
