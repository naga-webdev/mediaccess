(function(){
	angular.module("medicine")
	.controller("priyacontroller1",function($scope){
		
	});

}());
