(function(){
	angular.module("medicine").controller("priyacontroller2",function($scope,$http){
			
		$scope.status1="null";		
			
	
	$scope.add=function(){
		if($scope.mid1 &&
			$scope.symptoms1 &&
			$scope.count1){
			var data={
			
			mid:$scope.mid1,
			symptoms:$scope.symptoms1,
			tablet:$scope.tablet1,
			count:$scope.count1,
			others:$scope.others1,
			status:$scope.status1
			};
		console.log(data);
			$http.post("/doctorlist",data) // to post to server 
			.success(function(r,s,x){
				console.log(r);
				alert("request sent to database");
				//refresh();
			})
			.error(function(e,s,x){
				alert("error");
			});
			
	};
		
	};


	
	});
}());
