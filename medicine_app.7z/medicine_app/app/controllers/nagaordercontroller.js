(function(){
 angular.module("medicine").controller("nagaordercontroller",function($scope,$http){
   $scope.medname = null;
   $scope.quantity = null;
   $scope.date = null;
   $scope.success = "success";
   
    $scope.order = function(){
    	var name = $("#naganame").val();
    	var qty = $("#nagaquantity").val();
    	var dt = $("#nagadate").val();
    	var fun =$("nagafun").val();
    	
	    if(name && qty && dt && fun)
	    {
		     $scope.medname = $("#naganame").val();
		     $scope.quantity = $("#nagaquantity").val();
		     $scope.date = $("#nagadate").val();
		     
		     var data = {
		      medicine_name : $scope.medname,
		      quantity : $scope.quantity,
		      date : $scope.date,
		      status : "null"
		     };
		     
		     //console.log(data);
		     $http.post("/order",data)
		     .success(function(r,s,x){
		      console.log(r);
		      alert("request sent");
		     })
		     .error(function(e,s,x){
		      alert("Something went wrong");
		     });
	    }
    };
  });
}());