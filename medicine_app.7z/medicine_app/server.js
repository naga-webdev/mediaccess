var express = require("express");
var bp=require("body-parser");
var mongo = require("mongojs");

var db = mongo("medcn",["doctorlog","adminlog","medicine","login","doctorlist"]);

var app=express();
	app.use(express.static(__dirname));
	app.use(bp.json());
	
app.get("/",function(req,res){
	res.send();
});

app.get("/doctorlist/:id",function(req,res){
	console.log(req.body);
	var eid=req.params.id+"";
	console.log(eid);
	db.doctorlist.find({mid : eid},function(error,documents){
		console.log(documents);
		res.json(documents);
	})
})
 
app.post("/doctorlist",function(req,res){
	console.log(req.body);
	db.doctorlist.insert(req.body,function(error,documents){
	res.json(documents);
	//console.log(req.body);
	})
})

app.post("/login",function(req,res){
 //console.log(req.body);
 db.login.findOne({mid : req.body.mid, pwd : req.body.pwd },function(error,documents){
  //console.log(documents);
  res.json(documents);
 });
});

app.get("/doclog",function(req,res){
	console.log("i'm here");
	db.doctorlog.find({status :"null"},function(error,doc){
	//console.log(doc);
	res.json(doc);
	});
});

/*
app.post("/login",function(req,res){
 //console.log(req.body);
 db.login.findOne({mid : req.body.mid, pwd : req.body.pwd },function(error,documents){
  //console.log(documents);
  res.json(documents);
 });
});
 */

app.get("/adminlog",function(req,res){
	db.adminlog.find(function(error,documents){ //{status : "null"},
		res.json(documents);
	});
});

app.get("/doctorlog/:id",function(req,res){
 console.log(req.body);
 var eid=req.params.id+"";
 console.log(eid);
 db.doctorlog.find({mid : eid},function(error,documents){
  console.log(documents);
  res.json(documents);
 });
});
 app.get("/medicines",function(req,res){
 db.medicine.find(function(error,documents){ 
  res.json(documents);
 });
});
app.post("/doctorlog",function(req,res){
 console.log(req.body);
 db.doctorlog.insert(req.body,function(error,documents){
 res.json(documents);
 //console.log(req.body);
 });
});

app.post("/order",function(req,res){
  //console.log(req.body);
  db.adminlog.insert(req.body,function(error,documents){
   //console.log(documents);
   res.json(documents);
  });
});


app.post("/list",function(req,res){
 //res.header("Access-Control-Allow-Origin","*");
 //console.log(req.body);
 db.medicine.insert(req.body,function(err,documents){
  res.json(documents);
 });
 console.log("I'm a post Request . . . : for insert");
});


app.put("/approve/:id",function(req,res){
	var eid = req.params.id;
	console.log(eid);
	console.log("I'am getting a Edit request");
	db.doctorlog.findAndModify({
		query: {_id:mongo.ObjectId(eid)},
		update:{
		$set:{
		status : req.body.status
		} },
		new : true },function(error,data){
		console.log(error);
		res.json(data);		
		});
	});

app.put("/adminlog/:id",function(req,res){
	console.log("PUT",req.body);
	var id = req.params.id;
	db.adminlog.findAndModify({
		query : {_id:parseInt(id)},
		update : {$set : req.body},
		new : true
	},function(error, data){
		res.send(data);
	});
});
	
app.listen(1122);
console.log("Server is running on port 1122");